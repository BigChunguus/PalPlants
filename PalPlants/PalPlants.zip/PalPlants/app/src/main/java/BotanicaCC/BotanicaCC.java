/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BotanicaCC;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import PojosBotanica.src.pojosbotanica.*;

/**
 *
 * @author Alejandro
 */
public class BotanicaCC {

    /**
     * @param args the command line arguments
     */
    Socket socketCliente;
    
    private void manejadorIOException(IOException ex) throws ExcepcionBotanica {
        ExcepcionBotanica eb = new ExcepcionBotanica();
        eb.setMensajeUsuario("Fallo en las comunicaciones. Consulte con el administrador");
        eb.setMensajeErrorBd(ex.getMessage());
        throw eb;
    }
    private void manejadorClassNotFoundException(ClassNotFoundException ex) throws ExcepcionBotanica{
        ExcepcionBotanica eb = new ExcepcionBotanica();
        eb.setMensajeUsuario("Error general en el sistema. Consulte con el administrador");
        eb.setMensajeErrorBd(ex.getMessage());
        throw eb;
    }
    
    
    public BotanicaCC() throws ExcepcionBotanica {
        try {
            String equipoServidor = "172.16.206.69";
            int puertoServidor = 30500;
            socketCliente = new Socket(equipoServidor, puertoServidor);
            socketCliente.setSoTimeout(5000);
        } catch (IOException ex) {
            manejadorIOException(ex);
        }
    }
    
    public ArrayList<Usuario> leerUsuarios() throws ExcepcionBotanica {
        
        
        Peticion p = new Peticion();
        p.setIdOperacion(Operaciones.LEER_USUARIOS);
        
        
        Respuesta r = null;
        ArrayList<Usuario> listaUsuarios = null;
        
        try{
            
            ObjectOutputStream oos = new ObjectOutputStream(socketCliente.getOutputStream());
            oos.writeObject(p);
            ObjectInputStream ois = new ObjectInputStream(socketCliente.getInputStream());
            r = (Respuesta) ois.readObject();
            
            ois.close();
            oos.close();
            socketCliente.close();
            
            if(r.getEntidad() != null)
                listaUsuarios = (ArrayList<Usuario>) r.getEntidad();    
            else if (r.getEh() != null)
                throw r.getEh();
            
        } catch (ClassNotFoundException ex) {
            manejadorClassNotFoundException(ex);
        } catch(IOException ex){
            manejadorIOException(ex);
        }
        return listaUsuarios;
    }
    
    public int insertarUsuario(Usuario u) throws ExcepcionBotanica{
        
        Peticion p = new Peticion();
        p.setIdOperacion(Operaciones.INSERTAR_USUARIO);
        p.setEntidad(u);
        Respuesta r = null;
        int cambios = 0;
        
        try{
            
            ObjectOutputStream oos = new ObjectOutputStream(socketCliente.getOutputStream());
            oos.writeObject(p);
            ObjectInputStream ois = new ObjectInputStream(socketCliente.getInputStream());
            r = (Respuesta) ois.readObject();
            
            ois.close();
            oos.close();
            socketCliente.close();
            
            if(r.getCantidad() != null)
                cambios = (int) r.getCantidad();    
            else if (r.getEh() != null)
                throw r.getEh();
            
        } catch (ClassNotFoundException ex) {
            manejadorClassNotFoundException(ex);
        } catch(IOException ex){
            manejadorIOException(ex);
        }
        return cambios;
    }
}
